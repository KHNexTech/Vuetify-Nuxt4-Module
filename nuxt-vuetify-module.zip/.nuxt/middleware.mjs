import manifest_45route_45rule from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/middleware/manifest-route-rule.js";
export const globalMiddleware = [
  manifest_45route_45rule
]
export const namedMiddleware = {}