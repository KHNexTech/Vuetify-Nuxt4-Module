
export default {
  disableDefaults: true,
}