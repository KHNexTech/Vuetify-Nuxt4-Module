/// <reference types="vuetify-nuxt4-module" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxt/devtools" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="H:/Nuxt/nuxt-vuetify-module/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="types/middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
