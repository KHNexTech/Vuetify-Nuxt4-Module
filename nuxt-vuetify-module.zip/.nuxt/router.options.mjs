export const hashMode = false
export default {}