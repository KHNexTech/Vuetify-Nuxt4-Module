import { defineAsyncComponent } from 'vue'
export const islandComponents = import.meta.client ? {} : {

}