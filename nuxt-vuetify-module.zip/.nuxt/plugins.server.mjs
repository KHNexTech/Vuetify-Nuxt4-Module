import unhead_k2P3m_ZDyjlr2mMYnoDPwavjsDN8hBlk9cFai0bbopU from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/head/runtime/plugins/unhead.js";
import router_DclsWNDeVV7SyG4lslgLnjbQUK1ws8wgf2FHaAbo7Cw from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/plugins/router.js";
import vuetify_LFtB0QxuiAfJuFY7E1OXeGdzcgVoUlO2Xzkld1z35Y4 from "H:/Nuxt/nuxt-vuetify-module/src/runtime/plugins/vuetify.ts";
import revive_payload_server_MVtmlZaQpj6ApFmshWfUWl5PehCebzaBf2NuRMiIbms from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/plugins/revive-payload.server.js";
import components_plugin_z4hgvsiddfKkfXTP6M8M4zG5Cb7sGnDhcryKVM45Di4 from "H:/Nuxt/nuxt-vuetify-module/.nuxt/components.plugin.mjs";
export default [
  unhead_k2P3m_ZDyjlr2mMYnoDPwavjsDN8hBlk9cFai0bbopU,
  router_DclsWNDeVV7SyG4lslgLnjbQUK1ws8wgf2FHaAbo7Cw,
  vuetify_LFtB0QxuiAfJuFY7E1OXeGdzcgVoUlO2Xzkld1z35Y4,
  revive_payload_server_MVtmlZaQpj6ApFmshWfUWl5PehCebzaBf2NuRMiIbms,
  components_plugin_z4hgvsiddfKkfXTP6M8M4zG5Cb7sGnDhcryKVM45Di4
]