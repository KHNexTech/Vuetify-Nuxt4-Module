export { useRoute } from '#app/composables/router'
export const START_LOCATION = Symbol('router:start-location')