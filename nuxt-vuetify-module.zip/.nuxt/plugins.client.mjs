import revive_payload_client_kG4vF4SWGlhgLJRKrmco1O_zuG41odAu7e9PNPCDOtY from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/plugins/revive-payload.client.js";
import unhead_k2P3m_ZDyjlr2mMYnoDPwavjsDN8hBlk9cFai0bbopU from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/head/runtime/plugins/unhead.js";
import router_DclsWNDeVV7SyG4lslgLnjbQUK1ws8wgf2FHaAbo7Cw from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/plugins/router.js";
import vuetify_LFtB0QxuiAfJuFY7E1OXeGdzcgVoUlO2Xzkld1z35Y4 from "H:/Nuxt/nuxt-vuetify-module/src/runtime/plugins/vuetify.ts";
import payload_client_kSYcIMYUswSDcSGoGWqM0MO2T4MjOZsQFA1GU6fqohM from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/plugins/payload.client.js";
import navigation_repaint_client_iZ4sbIDUOBlI58WRS1dxkRZJOsKNs1c7SCqRszdxr6Y from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/plugins/navigation-repaint.client.js";
import check_outdated_build_client__GMdmUuNCTKDee9GyDhHz84CJEYUp5_FenYjvgAxtj8 from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/plugins/check-outdated-build.client.js";
import chunk_reload_client_90gdG_aWZaDfO85SQYWzwaOywz7zi0wBnFUoX0cT54U from "H:/Nuxt/nuxt-vuetify-module/node_modules/nuxt/dist/app/plugins/chunk-reload.client.js";
import components_plugin_z4hgvsiddfKkfXTP6M8M4zG5Cb7sGnDhcryKVM45Di4 from "H:/Nuxt/nuxt-vuetify-module/.nuxt/components.plugin.mjs";
export default [
  revive_payload_client_kG4vF4SWGlhgLJRKrmco1O_zuG41odAu7e9PNPCDOtY,
  unhead_k2P3m_ZDyjlr2mMYnoDPwavjsDN8hBlk9cFai0bbopU,
  router_DclsWNDeVV7SyG4lslgLnjbQUK1ws8wgf2FHaAbo7Cw,
  vuetify_LFtB0QxuiAfJuFY7E1OXeGdzcgVoUlO2Xzkld1z35Y4,
  payload_client_kSYcIMYUswSDcSGoGWqM0MO2T4MjOZsQFA1GU6fqohM,
  navigation_repaint_client_iZ4sbIDUOBlI58WRS1dxkRZJOsKNs1c7SCqRszdxr6Y,
  check_outdated_build_client__GMdmUuNCTKDee9GyDhHz84CJEYUp5_FenYjvgAxtj8,
  chunk_reload_client_90gdG_aWZaDfO85SQYWzwaOywz7zi0wBnFUoX0cT54U,
  components_plugin_z4hgvsiddfKkfXTP6M8M4zG5Cb7sGnDhcryKVM45Di4
]