
if (!("global" in globalThis)) {
  globalThis.global = globalThis;
}