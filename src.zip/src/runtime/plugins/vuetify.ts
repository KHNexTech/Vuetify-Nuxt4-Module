import { defineNuxtPlugin, type NuxtApp, useCookie, useRuntimeConfig } from '#app'
import { createVuetify } from 'vuetify'
import { watch } from 'vue'
import type { VuetifyOptions } from 'vuetify'
import type { VuetifyRuntimeConfig } from '../../types'
import {
  logger,
  callVuetifyHook,
  createIconConfig,
  createLocaleConfig,
  createDateConfig,
  loadBlueprint,
  resolvePersistenceConfig,
  setPersistedTheme,
  isI18nEnabled,
  createI18nLocaleAdapter,
  registerLazyComponents,
} from '../../utils'
import type { I18n } from 'vue-i18n'

// Extended NuxtApp interface for i18n
interface NuxtAppWithI18n extends NuxtApp {
  $i18n?: I18n
}

export default defineNuxtPlugin({
  name: 'vuetify',
  enforce: 'pre',
  parallel: true,
  async setup(nuxtApp) {
    const runtimeConfig = useRuntimeConfig().public.vuetify as VuetifyRuntimeConfig
    const {
      vuetifyOptions: config,
      persistence: persistenceOptions,
      i18n: i18nOption,
      lazyComponents: lazy,
    } = runtimeConfig

    logger.debug('Initializing Vuetify...')

    // Resolve persistence config
    const persistenceConfig = resolvePersistenceConfig(persistenceOptions)

    // Get persisted theme BEFORE creating Vuetify (works on both SSR and client)
    let initialTheme = config.theme?.defaultTheme ?? 'light'

    if (persistenceConfig.enabled && persistenceConfig.storage === 'cookie') {
      const themeCookie = useCookie<string>(persistenceConfig.key, {
        maxAge: persistenceConfig.cookieOptions?.maxAge,
        path: persistenceConfig.cookieOptions?.path,
        sameSite: persistenceConfig.cookieOptions?.sameSite as 'lax' | 'strict' | 'none',
      })

      if (themeCookie.value) {
        initialTheme = themeCookie.value
      }
    }

    // Build options
    const vuetifyOptions: VuetifyOptions = {
      ssr: config.ssr ?? true,
      theme: {
        ...config.theme,
        defaultTheme: initialTheme,
      },
      defaults: config.defaults,
      aliases: config.aliases as VuetifyOptions['aliases'],
    }

    // Load async configurations in parallel
    const [blueprint, dateConfig, iconConfig, localeConfig] = await Promise.all([
      config.blueprint ? loadBlueprint(config.blueprint) : undefined,
      config.dateAdapter && config.dateAdapter !== 'vuetify' ? createDateConfig(config.dateAdapter) : undefined,
      config.icons ? createIconConfig(config.icons) : createIconConfig(),
      config.locale ? createLocaleConfig(config.locale) : createLocaleConfig(),
    ])

    // Apply loaded configs
    if (blueprint) vuetifyOptions.blueprint = blueprint
    if (dateConfig) vuetifyOptions.date = dateConfig
    if (iconConfig) vuetifyOptions.icons = iconConfig

    // Handle i18n adapter - only on client side to avoid hydration mismatch
    let i18nLocaleAdapter
    if (isI18nEnabled(i18nOption)) {
      try {
        // Get i18n instance from nuxt app
        // @nuxtjs/i18n provides it as $i18n
        const appWithI18n = nuxtApp as NuxtAppWithI18n
        const i18nInstance = appWithI18n.$i18n
        if (i18nInstance) {
          i18nLocaleAdapter = await createI18nLocaleAdapter(i18nInstance)
        }
      }
      catch (error) {
        logger.debug('i18n adapter creation skipped:', error)
      }
    }
    // Apply locale config - i18n adapter takes precedence over default locale config
    if (i18nLocaleAdapter) {
      vuetifyOptions.locale = i18nLocaleAdapter
    }
    else if (localeConfig) {
      vuetifyOptions.locale = localeConfig
    }

    /// Hook: before-create
    await callVuetifyHook(nuxtApp as NuxtApp, 'vuetify:before-create', { vuetifyOptions })

    // Create Vuetify instance
    const vuetify = createVuetify(vuetifyOptions)

    // Install Vuetify
    nuxtApp.vueApp.use(vuetify)

    // Lazy Components
    if (lazy) {
      const lazyConfig = typeof lazy === 'object'
        ? lazy
        : {}

      registerLazyComponents(
        nuxtApp.vueApp,
        lazyConfig?.components,
        { delay: lazyConfig.delay },
      )
    }

    // Handle theme persistence watcher (client-only)
    if (import.meta.client && persistenceConfig.enabled) {
      // Watch for theme changes and persist them
      watch(
        () => vuetify.theme.global.name.value,
        (theme) => {
          setPersistedTheme(persistenceConfig, theme)

          // Also update the cookie for SSR
          if (persistenceConfig.storage === 'cookie') {
            const themeCookie = useCookie<string>(persistenceConfig.key, {
              maxAge: persistenceConfig.cookieOptions?.maxAge,
              path: persistenceConfig.cookieOptions?.path,
              sameSite: persistenceConfig.cookieOptions?.sameSite as 'lax' | 'strict' | 'none',
            })
            themeCookie.value = theme
          }
        },
      )

      // Handle localStorage persistence (client-only read)
      if (persistenceConfig.storage === 'localStorage') {
        const storedTheme = localStorage.getItem(persistenceConfig.key)
        if (storedTheme && vuetify.theme.themes.value[storedTheme]) {
          vuetify.theme.global.name.value = storedTheme
        }
      }
    }

    // Hook: configuration
    await callVuetifyHook(nuxtApp as NuxtApp, 'vuetify:configuration', { vuetifyOptions })

    // Hook: ready
    await callVuetifyHook(nuxtApp as NuxtApp, 'vuetify:ready', vuetify)

    logger.success('Vuetify initialized')
    nuxtApp.provide('vuetify', vuetify)
  },
})
